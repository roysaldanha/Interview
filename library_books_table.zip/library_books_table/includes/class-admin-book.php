<?php 




if ( ! class_exists( 'BookTableAdmin' ) ) :
/**
 * The main idea behind this class is to load the most recent version of the scb classes available.
 *
 * It waits until all plugins are loaded and then does some crazy hacks to make activation hooks work.
 */
class BookTableAdmin {

	static function init( $callback = '' ) {            
                add_action( 'admin_menu',  array( __CLASS__, 'bt_setup_admin_menu' ) );
                register_activation_hook( BT_PLUGIN_FILE,  array( __CLASS__, 'bt_activate_plugin' ) );                
                add_action( 'admin_post_save_book_details', array( __CLASS__, 'bt_save_book_details') );                            
                add_action( 'admin_post_trash_book', array( __CLASS__, 'bt_delete_book_details') );                
                add_shortcode('BTFULLTABLE',array( __CLASS__, 'bt_show_full_table'));
                add_action('wp_enqueue_scripts', array( __CLASS__, 'wp_datatable_enqueue'));
	}

        function bt_delete_book_details() {
            global $wpdb;
            $table_name = $wpdb->prefix."book_details";
                
            if(is_numeric($_POST['hidBookId'])) {
                $wpdb->update( $table_name, 
                        array( 'active_status' => 'N' ), 
                        array( 'book_id' => $_POST['hidBookId'] ));

            }
            wp_redirect( admin_url( '/admin.php?page=viewbook' ), 301 );
            exit;
        }
        
        function bt_save_book_details() {
            global $wpdb;
            $table_name = $wpdb->prefix."book_details";

            $error = false;

            if (empty($_POST['book-name'])) {
                $error = true;
            }

            if (empty($_POST['book-author'])) {
                $error = true;
            }

            if ( empty($_POST['book-description'])) {
                $error = true;
            }

            if(!$error) {

                $wpdb->insert($table_name, array(
                        'book_name'=> sanitize_text_field($_POST['book-name']),
                        'author'=> sanitize_text_field($_POST['book-author']),
                        'description'=> sanitize_textarea_field($_POST['book-description'])));

                wp_redirect( admin_url( '/admin.php?page=viewbook' ), 301 );
                exit;
            }
        }
        
        function bt_setup_admin_menu(){
                add_menu_page( 'Info', 'Info', '', 'booksmainmenu', 'booksmainmenu', 'dashicons-admin-page', 10 );
                add_submenu_page ( 'booksmainmenu', 'Add Book', 'Add Book', 'read', 'addbook', array( __CLASS__, 'addBookForm' ));
                add_submenu_page ( 'booksmainmenu', 'View Books', 'Books', 'read', 'viewbook', array( __CLASS__, 'getAllBooksList' ));
        }
        
        function bt_activate_plugin() { 
            global $wpdb;

            $wpdb->hide_errors();

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';

            $collate = '';

            if ( $wpdb->has_cap( 'collation' ) ) {
                    $collate = $wpdb->get_charset_collate();
            }

            $tables = " CREATE TABLE {$wpdb->prefix}book_details (
                            book_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                            book_name longtext NOT NULL,
                            author longtext NOT NULL,
                            description longtext NOT NULL,
                            active_status enum('Y','N') NOT NULL DEFAULT 'Y',
                            PRIMARY KEY  (book_id) ) $collate;";
            dbDelta($tables );
        }

        function addBookForm(){  ?>
            <div class="wrap">

                <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

                <form method="post" action="<?php echo esc_html( admin_url( 'admin-post.php' ) ); ?>" name="bookAddForm" id="bookAddForm">
                    <input type="hidden" name="action" value="save_book_details">
                        <div id="universal-message-container">
                            <h2>Universal Message</h2>

                            <div class="options">
                                <p>
                                    <label>Book Name</label>
                                    <br />
                                    <input type="text" name="book-name" id="book-name" value="" />
                                </p>
                            </div><!-- #universal-message-container -->

                            <div class="options">
                                <p>
                                    <label>Author</label>
                                    <br />
                                    <input type="text" name="book-author" id="book-author" value="" />
                                </p>
                            </div><!-- #universal-message-container -->

                            <div class="options">
                                <p>
                                    <label>Description</label>
                                    <br />
                                    <textarea name="book-description" id="book-description"></textarea>
                                </p>
                            </div><!-- #universal-message-container -->

                            <input type="button" id="submitBookAdd" name="submitBookAdd" value="Save" class="button button-primary">
                        </div>

                    </form>
                <script>
                    jQuery(document).ready(function () {
                       jQuery("#submitBookAdd").click(function(){
                           var error = false;

                           if(jQuery("#book-name").val() == '') {
                               error = true
                           }

                           if(jQuery("#book-author").val() == '') {
                               error = true
                           }

                           if(jQuery("#book-description").val() == '') {
                               error = true
                           }

                           if(error == false) {
                               jQuery("#bookAddForm").submit();
                           } else {
                               alert("Please fill all the fields.");
                               return false;
                           }
                       });
                    });
                </script>

            </div><!-- .wrap --><?php 
        } 
        
        
        function getAllBooksList() { 
                global $wpdb;
                $table_name = $wpdb->prefix . "book_details";

                $pagenum = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;      

                $limit = 10; // number of rows in page
                $offset = ( $pagenum - 1 ) * $limit;
                $total = $wpdb->get_var( "select count(*) as total from $table_name where active_status='Y'" );
                $num_of_pages = ceil( $total / $limit );

                $rows = $wpdb->get_results( "SELECT * from $table_name  where active_status='Y' limit  $offset, $limit" );
                $rowcount = $wpdb->num_rows; ?>
            
                <div class="wrap abs">
                    <h1 class="wp-heading-inline"><?php echo esc_html( get_admin_page_title() ); ?></h1>
                    <a href="<?php echo admin_url('admin.php?page=addbook'); ?>" class="page-title-action">Add New</a>
                    <?php
                     // wp_upload_dir has diffrent types of array I am used 'baseurl' for path

                    ?>
                    <form method="post" action="<?php echo esc_html( admin_url( 'admin-post.php' ) ); ?>" name="bookAddForm" id="bookAddForm">
                        <input type="hidden" name="action" value="trash_book">
                        <input type="hidden" id="hidBookId" name="hidBookId" value="">
                    </form>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>City</th>
                                <th>State</th>
                                <th width="5%">&nbsp;</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>ID</th>
                                <th>City</th>
                                <th>State</th>
                                <th>&nbsp;</th>
                            </tr>
                        </tfoot>
                        <?php
                        if($rowcount>0){ ?>
                        <tbody>
                        <?php foreach ($rows as $row) { ?>
                            <tr>
                                <td class="manage-column ss-list-width"><?php echo $row->book_id; ?></td>
                                <td class="manage-column ss-list-width"><?php echo $row->book_name; ?></td>
                                <td class="manage-column ss-list-width"><?php echo $row->author; ?></td>
                                <td><a onclick="deletethis('<?php echo  $row->book_id; ?>'); return false;">Delete</a></td>
                            </tr>
                        <?php } }else{
                            echo "<tr><td cols=an='5'>No records found</td></tr>";
                        } ?>
                        </tbody>
                    </table>
                    <script>
                        function deletethis(book_id) {
                            if(confirm("do you really want to delete this book details?")) {
                                jQuery("#hidBookId").val(book_id);
                                jQuery("#bookAddForm").submit();
                            }
                        }
                    </script>
                </div>
                <?php

                $page_links = paginate_links( array(
                    'base' => add_query_arg( 'pagenum', '%#%' ),
                    'format' => '',
                    'prev_text' => __( '&laquo;', 'text-domain' ),
                    'next_text' => __( '&raquo;', 'text-domain' ),
                    'total' => $num_of_pages,
                    'current' => $pagenum
                ) );

                if ( $page_links ) {
                    echo '<div class="tablenav" style="width: 99%;"><div class="tablenav-pages" style="margin: 1em 0">' . $page_links . '</div></div>';
                }
        }        
        

        function wp_datatable_enqueue()
        {
                define('WP_DATATABLE_VERSION', '1.10.15');

                wp_register_style('wp-datatable-style', plugins_url('../../css/datatables.min.css?v=' . WP_DATATABLE_VERSION, __FILE__));
                wp_register_script('wp-datatable-script', plugins_url('../../js/datatables.min.js?v=' . WP_DATATABLE_VERSION, __FILE__));
        }


        function bt_show_full_table(){ 
            $id = 'btDetailsTable';
            global $wpdb;  
            $table_name = $wpdb->prefix . "book_details";
            $results = $wpdb->get_results( "SELECT * from $table_name  where active_status='Y'" ); ?>

            <table id="<?php echo $id; ?>">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Age</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Age</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach( $results as $user_data) { ?>
                    <tr>
                        <td><?php echo $user_data->book_id ?></td>
                        <td><?php echo $user_data->book_name ?></td>
                        <td><?php echo $user_data->author ?></td>
                        <td><?php echo $user_data->description ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            
            <?php
            wp_enqueue_style('wp-datatable-style');
            wp_enqueue_script('wp-datatable-script');

            $content = 'jQuery(document).ready(function () { jQuery(' . "'#$id'" . ').DataTable({' . $content . '}); });';

            return '<script type="text/javascript">' .
                            $content .
                    '</script>';

        }
}
endif;

if ( ! function_exists( 'book_table_init' ) ) :
function book_table_init( $callback = '' ) {
	BookTableAdmin::init( $callback );
}
endif;