<?php 




if ( ! class_exists( 'BookTableAdmin' ) ) :
/**
 * The main idea behind this class is to load the most recent version of the scb classes available.
 *
 * It waits until all plugins are loaded and then does some crazy hacks to make activation hooks work.
 */
class BookTableAdmin {

	static function init( $callback = '' ) {                            
                add_shortcode('BTFULLTABLE',array( __CLASS__, 'bt_show_full_table'));
                add_action('wp_enqueue_scripts', array( __CLASS__, 'wp_datatable_enqueue'));
	}   
        

        function wp_datatable_enqueue()
        {
                define('WP_DATATABLE_VERSION', '1.10.15');

                wp_register_style('wp-datatable-style', plugins_url('../../css/datatables.min.css?v=' . WP_DATATABLE_VERSION, __FILE__));
                wp_register_script('wp-datatable-script', plugins_url('../../js/datatables.min.js?v=' . WP_DATATABLE_VERSION, __FILE__));
        }


        function bt_show_full_table(){ 
            $id = 'btDetailsTable';
            global $wpdb;  
            $table_name = $wpdb->prefix . "book_details";
            $results = $wpdb->get_results( "SELECT * from $table_name  where active_status='Y'" ); ?>

            <table id="<?php echo $id; ?>">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Age</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Age</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach( $results as $user_data) { ?>
                    <tr>
                        <td><?php echo $user_data->book_id ?></td>
                        <td><?php echo $user_data->book_name ?></td>
                        <td><?php echo $user_data->author ?></td>
                        <td><?php echo $user_data->description ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            
            <?php
            wp_enqueue_style('wp-datatable-style');
            wp_enqueue_script('wp-datatable-script');

            $content = 'jQuery(document).ready(function () { jQuery(' . "'#$id'" . ').DataTable({' . $content . '}); });';

            return '<script type="text/javascript">' .
                            $content .
                    '</script>';

        }
}
endif;

if ( ! function_exists( 'book_table_init' ) ) :
function book_table_init( $callback = '' ) {
	BookTableAdmin::init( $callback );
}
endif;