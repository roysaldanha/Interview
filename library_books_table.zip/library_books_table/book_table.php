<?php
   /*
   Plugin Name: Books Table
   Plugin URI: http://google.com
   description: A plugin to add and view book details
   Version: 1.2
   Author: Mr. Roy Saldanha
   Author URI: http://google.com
   License: GPL2
   */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define WC_PLUGIN_FILE.
if ( ! defined( 'BT_PLUGIN_FILE' ) ) {
	define( 'BT_PLUGIN_FILE', __FILE__ );
}

// Include the main WooCommerce class.
if ( is_admin()) {
    include_once dirname( __FILE__ ) . '/includes/class-admin-book.php';    
    book_table_init( '' );
    
} else {
    include_once dirname( __FILE__ ) . '/includes/class-front-book.php';    
    book_table_init( '' );
}
