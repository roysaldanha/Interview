<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div class="woof_products_top_panel"></div>